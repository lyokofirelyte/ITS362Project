<?php
	echo("<div class='twitter_auth' id='" . $url . "'>Authorize on Twitter</div>");
?>