<div id="footer">
	<hr>
	<p style='text-align: center'>ITS 362 Project - David Tossberg & Kyle McManimen</p>
</div>
