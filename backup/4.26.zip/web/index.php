<html>
	<head>
		<link rel="stylesheet" href="css/module.css" />
		<link rel="stylesheet" href="css/global.css" />
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<?php 
	session_start();
	require "../vendor/autoload.php";
	require "includes/dir_config.php";

    $views = array();
    $go = 0;
    
    if (!isset($_SESSION["bg"])){
    	$_SESSION["bg"] = "../img/bg.png";
    }
    
    if (!isset($_SESSION["header"])){
    	$_SESSION["header"] = "../img/header_2.png";
    }
    
    if (isset($_POST["link_twitter"])){
    	$_SESSION["link_twitter"] = $_POST["link_twitter"];
    }
	
	if (isset($_POST["youtube_search"])){
		$_SESSION["youtube_search"] = $_POST["youtube_search"];
	}
	
	if (isset($_POST["twitter_linked"])){
		$_SESSION["twitter_linked"] = $_POST["twitter_linked"];
		if ($_POST["twitter_linked"] == 1){
			$_SESSION["displayTwitter"] = "yes";
		} else {
			unset($_SESSION["twitter_statuses"]);
			unset($_SESSION["oauth_token"]);
			unset($_SESSION["oauth_token_secret"]);
			unset($_SESSION["twitter"]["access_token"]);
			unset($_SESSION["link_twitter"]);
			$email = $_SESSION['email'];
			//remove twitter link from user table for that email and on twitter itself
			$sql = "update user set twitter=NULL where email='$email';";
			//run query
			$r = mysqli_query($dbc, $sql);
			//remove row from twitter table
			$sql = "delete from twitter where email='$email';";
			//run query
			$r = mysqli_query($dbc, $sql);
			$_SESSION["displayTwitter"] = "no";
		}
	}

	if (isset($_POST["logged_in"])){
		$_SESSION["user"]["logged_in"] = $_POST["logged_in"];
        if ($_POST["logged_in"] == 1){
            $_SESSION = array();
            session_destroy();
            session_start();
            $_SESSION["bg"] = "../img/bg.png";
            $_SESSION["header"] = "../img/header_2.png";
            $go = 1;
        } else if ($_POST["logged_in"] == 0) {
        	$_SESSION["email"] = $_POST["login_email"];
        }
	}
	
	if ($go == 0){
	    if (isset($_POST["update_views"])){
	        foreach ($_POST["update_views"] as $update_key){
	            array_push($views, $update_key);
	        }
	    }
	
	    if (!isset($_SESSION["user"]["logged_in"]) || $_SESSION["user"]["logged_in"] >= 1){
	        if (sizeof($views) == 0){
	            array_push($views, "login");
	        }
	    }
	
	    if (isset($_SESSION["user"]["verified"]) && $_SESSION["user"]["verified"] == "yes"){
	        array_push($views, "content");
	    }
	} else {
		array_push($views, "login");
	}
?>
		<script type="text/javascript">
			<?php if(!isset($_POST["twitter_linked"])){ $_SESSION["displayTwitter"] = "yes";}?>
		var twitter_linked = <?php if (isset($_SESSION["twitter_linked"])){ echo $_SESSION["twitter_linked"];} else {echo 0;}  ?>;
		</script>
		<script src="js/module_main.js"></script>
		<script src="js/jsutils.js"></script>
	</head>
	<?php 
		echo("<body style=\"background: url('" . $_SESSION["bg"] . "'); background-size: cover; background-repeat: no-repeat; background-position: center center;\">");
		include(fromIncludes("header.php"));
	?>
        <div class="all_noscroll">
            <div class="all">
                <?php 
                    foreach ($views as $view){
                        include(fromIncludes($view . ".php"));
                    }
                    echo("<script type='text/javascript'>pageDone();</script>");
                ?>
            </div>
        </div>
        <?php 
      	  include(fromIncludes("sidebar.php"));
      	  if (isset($_POST["file_bg"])){
      	  	include(fromIncludes("files.php"));
      	  }
      	  if (isset($_POST["header_file_submit"])){
      	  	include(fromIncludes("files.php"));
      	  }
        ?>
	</body>
</html>